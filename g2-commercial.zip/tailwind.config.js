module.exports = {
  content: ['./*.html'], // Ensures it scans your HTML files
  theme: {
    extend: {},
  },
  plugins: [],
};
